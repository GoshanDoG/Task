public class Main {
    public static void main(String[] args) {

        Rent firstPlace = new Rent();
        Rent secondPlace = new Rent();

        firstPlace.district = "Ульянка";
        firstPlace.address = "Генерала Симоняка 4 к1";
        firstPlace.rentPerMonth = 14000;
        firstPlace.setRentPerYear();

        secondPlace.district = "Адмиралтейский";
        secondPlace.address = "Проспект Римского-Корсакова 14";
        secondPlace.rentPerMonth = 33000;
        secondPlace.setRentPerYear();

        System.out.println(" ");
        if (firstPlace.rentPerYear < secondPlace.rentPerYear) {
            System.out.println("*На Проспекте Римского-Корсакова дороже аренда но больше проходимость");
        }

        System.out.println(" ");
        System.out.println("*ПОДСЧЁТЫ ПО РЕНТЕ ЗАВЕРШЕНЫ*");

        Coffee arabica = new Coffee();
        Coffee robusta = new Coffee();
        Coffee liberica = new Coffee();

        arabica.brand = "lavazza Qualita Oro";
        arabica.weightInGrams = 1000;
        arabica.pricePerPurchase = 1189;
        arabica.countRublePerGram();
        arabica.countMargin();

        robusta.brand = "lavazza Qualita Oro";
        robusta.weightInGrams = 1000;
        robusta.pricePerPurchase = 1400;
        robusta.countRublePerGram();
        robusta.countMargin();

        liberica.brand = "India Anohki Coffe";
        liberica.weightInGrams = 900;
        liberica.pricePerPurchase = 1125;
        liberica.countRublePerGram();
        liberica.countMargin();


        System.out.println(" ");
        System.out.println("*ПОДСЧЁТЫ ПО КОФЕ ЗАВЕРШЕНЫ*");


        Employees barista = new Employees();
        Employees cleaner = new Employees();

        barista.nameAndSurname = "Владимир Епифанцев";
        barista.jobTitle = "Бариста";
        barista.daySalary = 1700;
        barista.daysOnTheWork = 20;
        barista.countMonthlySalary();

        cleaner.nameAndSurname = "Сергей Пахомов";
        cleaner.jobTitle = "Уборщик";
        cleaner.daySalary = 1200;
        cleaner.daysOnTheWork = 4;
        cleaner.countMonthlySalary();

        System.out.println(" ");
        System.out.println("*ПОДСЧЁТЫ ПО РАБОТНИКАМ ЗАВЕРШЕНЫ*");

        Profit.countExpencesPerMonth(secondPlace.rentPerMonth, barista.salaryPerMonth + cleaner.salaryPerMonth );
        Coffee.countRevenuePerMonth(arabica.weightInGrams, arabica.priceWithMargin);
        Coffee.countRevenuePerMonth(robusta.weightInGrams, robusta.priceWithMargin);
        Coffee.countRevenuePerMonth(liberica.weightInGrams, liberica.priceWithMargin);
        System.out.println(arabica.revenue + robusta.revenue + liberica.revenue + " Суммарная прибыль от продажи кофе");
        System.out.println("Поздравляю, мы вышли в плюс на " + (arabica.revenue + robusta.revenue + liberica.revenue + Profit.expences));

        System.out.println(" ");
        System.out.println("*ПОДСЧЁТЫ ПО РАБОТНИКАМ ЗАВЕРШЕНЫ*");
        }
    }
