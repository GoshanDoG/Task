public class Profit {
    public static double expences;

    public static void countExpencesPerMonth(double rentPerMonth, double salaryPerMonth) {
        expences = (rentPerMonth + salaryPerMonth) * -1 ;
        System.out.println(expences + " Затраты за месяц");
    }
}

