public class Coffee {
    public double rublePerGram;
    public double weightInGrams;
    public double pricePerPurchase;
    public String brand;
    public double priceWithMargin;

    public static double revenue;
    public static double numberOfCups;


    public void countRublePerGram() {
        rublePerGram = pricePerPurchase / weightInGrams;

        System.out.println(" ");

        System.out.println("Название бренда кофе: " + brand);

        System.out.println("Стоимость за пачку: " + pricePerPurchase + "рублей");

        System.out.println("Грамм в пачке: " + weightInGrams);

        System.out.println("Cтоимость за грамм: " + rublePerGram + "рублей");

        System.out.println();
    }

    public void countMargin() {
        priceWithMargin = rublePerGram * 1.3;
        System.out.println("Допустимая максимальная маржа для нашего заведения: " + priceWithMargin);
    }

    public static void countRevenuePerMonth(double weightInGrams, double priceWithMargin) {
        numberOfCups = (weightInGrams / 9);
        revenue = numberOfCups * priceWithMargin * 200;
    }
}

