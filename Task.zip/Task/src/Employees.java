public class Employees {
    public String nameAndSurname;
    public String jobTitle;
    public int daySalary;
    public double salaryPerMonth;
    public int daysOnTheWork;
    public double salaryPerYear;

    public void countMonthlySalary() {
        salaryPerMonth = daysOnTheWork * daySalary;

        salaryPerYear = salaryPerMonth * 12;
        System.out.println(" ");

        System.out.println("Должность: " + jobTitle);

        System.out.println("Имя и фамилия: " + nameAndSurname);

        System.out.println("Дней отработано: " + daysOnTheWork);

        System.out.println("заработано за месяц: " + salaryPerMonth);

        System.out.println("заработано за год: " + salaryPerYear);
    }
}
