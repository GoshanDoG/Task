public class Rent {
    public String district;
    public String address;
    public double rentPerMonth;
    public double rentPerYear;

    public void setRentPerYear() {
        System.out.println(" ");
        System.out.println("район: " + district);
        System.out.println("адрес: " + address);
        System.out.println("месяная рента: " + rentPerMonth);
        rentPerYear = rentPerMonth * 12;
        System.out.println("годовая рента: " + rentPerYear);
        System.out.println();
    }
}
